package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;

public class AdminListAnakKosActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private LinearLayout buttonBack;
    private RecyclerView recyclerView;
    listAnakKosAdapter adapterAnakKos;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_listanakkos);

        Bundle extras = getIntent().getExtras();
        String namaKos = extras.getString("namaKos");

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);

        buttonBack = findViewById(R.id.btnBack);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonAdd.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        recyclerView = findViewById(R.id.recyclerListAnakKos);
        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
        Query query = FirebaseDatabase.getInstance().getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/users").orderByChild("lokasiKos").equalTo(namaKos);
        FirebaseRecyclerOptions<listAnakKos> options = new FirebaseRecyclerOptions.Builder<listAnakKos>().setQuery(query, listAnakKos.class).build();
        adapterAnakKos = new listAnakKosAdapter(options);
        recyclerView.setAdapter(adapterAnakKos);

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminListAnakKosActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminListAnakKosActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminListAnakKosActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminListAnakKosActivity.this.finish();
            }
        });
    }

    @Override protected void onStart()
    {
        super.onStart();
        adapterAnakKos.startListening();
    }

    @Override protected void onStop()
    {
        super.onStop();
        adapterAnakKos.stopListening();
    }
}