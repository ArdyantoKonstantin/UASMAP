package id.ac.umn.darren_hard_carry_uas_map;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.view.LayoutInflater;
import android.view.ViewGroup;
import androidx.annotation.NonNull;
import android.view.View;
import android.widget.LinearLayout;
import android.widget.TextView;
import androidx.recyclerview.widget.RecyclerView;
import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class ListMasalahAdapter extends FirebaseRecyclerAdapter<ListMasalah, ListMasalahAdapter.ListMasalahViewHolder>{
    private Context context;

    public ListMasalahAdapter(@NonNull FirebaseRecyclerOptions<ListMasalah> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull ListMasalahViewHolder holder, int position, @NonNull ListMasalah model) {
        holder.namaPelapor.setText(model.getPelapor());
        holder.namaMasalah.setText(model.getNamaMasalah());
        holder.UpVote.setText(String.valueOf(model.getUpVote()));
        holder.lokasiMasalah.setText(model.getLokasi());
        holder.status.setText(model.getStatus());
        holder.tanggalLaporan.setText(model.getTanggalPelaporan());
        holder.linkGambar.setText(model.getLinkGambar());
        holder.detailLaporan.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Bundle bundle = new Bundle();
                bundle.putString("namaPelapor", model.getPelapor());
                bundle.putString("namaMasalah", model.getNamaMasalah());
                bundle.putInt("UpVote", model.getUpVote());
                bundle.putString("lokasiMasalah", model.getLokasi());
                bundle.putString("status", model.getStatus());
                bundle.putString("tanggalLaporan", model.getTanggalPelaporan());
                bundle.putString("linkGambar", model.getLinkGambar());
                SharedPreferences sh = holder.itemView.getContext().getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                String statusUser = sh.getString("position", "");
                if(statusUser.equals("Admin")){
                    Intent intent = new Intent(holder.itemView.getContext(), AdminDetailLaporanActivity.class);
                    intent.putExtras(bundle);
                    holder.itemView.getContext().startActivity(intent);
                }
                else{
                    Intent intent = new Intent(holder.itemView.getContext(), UserDetailLaporanActivity.class);
                    intent.putExtras(bundle);
                    holder.itemView.getContext().startActivity(intent);
                }

            }
        });
    }


    @NonNull
    @Override
    public ListMasalahViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_masalah, parent, false);
        return new ListMasalahAdapter.ListMasalahViewHolder(view);
    }


    public class ListMasalahViewHolder extends RecyclerView.ViewHolder {
        TextView namaPelapor, namaMasalah, UpVote, lokasiMasalah, status, tanggalLaporan, linkGambar;
        LinearLayout detailLaporan;
        public ListMasalahViewHolder(@NonNull View itemView) {
            super(itemView);
            namaPelapor = itemView.findViewById(R.id.namaPelapor);
            namaMasalah = itemView.findViewById(R.id.namaMasalah);
            UpVote = itemView.findViewById(R.id.UpVote);
            lokasiMasalah = itemView.findViewById(R.id.lokasiMasalah);
            status = itemView.findViewById(R.id.status);
            tanggalLaporan = itemView.findViewById(R.id.tanggalLaporan);
            linkGambar = itemView.findViewById(R.id.linkGambar);
            detailLaporan = itemView.findViewById(R.id.btnDetailLaporan);
        }
    }
}
