package id.ac.umn.darren_hard_carry_uas_map;

public class listAnakKos {
    private String nama, email, lokasiKos;


    public String getNama() {
        return nama;
    }

    public void setNama(String nama) {
        this.nama = nama;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLokasiKos() {
        return lokasiKos;
    }

    public void setLokasiKos(String lokasiKos) {
        this.lokasiKos = lokasiKos;
    }
}
