package id.ac.umn.darren_hard_carry_uas_map;

import android.app.ActivityOptions;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import androidx.recyclerview.widget.LinearLayoutManager;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.graphics.PorterDuff.Mode;
import android.widget.Spinner;
import android.widget.Toast;

import com.firebase.ui.database.FirebaseRecyclerOptions;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminHomeActivity extends AppCompatActivity implements  AdapterView.OnItemSelectedListener{

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private Spinner dropdownPilihKos;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private List<String> list;
    private RecyclerView recyclerView;
    ListMasalahAdapter adapterRecyclerView;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_home);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        dropdownPilihKos = findViewById(R.id.dropdownPilihKos);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonHome.setColorFilter(newColor, Mode.SRC_ATOP);
        list = new ArrayList<>();

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");

        databaseReference.child("ListKos").orderByChild("pemilikKos").equalTo(username).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()){
                    String kos  = ds.child("namaKos").getValue(String.class);
                    list.add(kos);
                }
                ArrayAdapter<String> adapter = new ArrayAdapter<String>(AdminHomeActivity.this, android.R.layout.simple_spinner_dropdown_item, list);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                dropdownPilihKos.setAdapter(adapter);
                dropdownPilihKos.setOnItemSelectedListener(new AdapterView.OnItemSelectedListener() {
                    @Override
                    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
                        recyclerView = findViewById(R.id.recyclerListMasalah);
                        recyclerView.setLayoutManager(new LinearLayoutManager(getApplicationContext()));
                        Query query = FirebaseDatabase.getInstance().getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/ListMasalah").orderByChild("lokasi").equalTo(parent.getItemAtPosition(i).toString());
                        FirebaseRecyclerOptions<ListMasalah> options = new FirebaseRecyclerOptions.Builder<ListMasalah>().setQuery(query, ListMasalah.class).build();
                        adapterRecyclerView = new ListMasalahAdapter(options);
                        adapterRecyclerView.startListening();
                        recyclerView.setAdapter(adapterRecyclerView);
                    }

                    @Override
                    public void onNothingSelected(AdapterView<?> adapterView) {

                    }
                });
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Database Error.", Toast.LENGTH_SHORT).show();
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminHomeActivity.this, AdminAddActivity.class);
                startActivity(intent, null);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminHomeActivity.this, AdminProfileActivity.class);
                startActivity(intent, null);
            }
        });
    }

    @Override
    public void onItemSelected(AdapterView<?> parent, View view, int i, long l) {
        Toast.makeText(parent.getContext(), "The planet is " + parent.getItemAtPosition(i).toString(), Toast.LENGTH_LONG).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }

    @Override
    protected void onStop()
    {
        super.onStop();
        adapterRecyclerView.stopListening();
    }

}