package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

public class UserEditProfileActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile, buttonLogout;
    private LinearLayout buttonBack;
    private RadioGroup radioGroup;
    private RadioButton radioButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_editprofile);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonLogout = findViewById(R.id.btnLogout);
        buttonBack = findViewById(R.id.btnBack);
        radioGroup = findViewById(R.id.radioGroup);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonProfile.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setDisplayHomeAsUpEnabled(true);

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserEditProfileActivity.this, UserHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserEditProfileActivity.this, UserAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserEditProfileActivity.this, UserProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(), "Logged Out", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(UserEditProfileActivity.this, LandingPilihActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserEditProfileActivity.this.finish();
            }
        });
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                this.finish();
//                return true;
//            case R.id.action_logout:
//                Toast.makeText(this, "Logged Out", Toast.LENGTH_LONG).show();
//                Intent intent = new Intent(UserEditProfileActivity.this, LandingPilihActivity.class);
//                startActivity(intent);
//                return(true);
//        }
//        return super.onOptionsItemSelected(item);
//    }
}