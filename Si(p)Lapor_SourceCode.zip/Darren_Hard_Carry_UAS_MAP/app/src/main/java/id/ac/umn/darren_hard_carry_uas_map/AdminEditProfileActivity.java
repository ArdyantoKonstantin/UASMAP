package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminEditProfileActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile, buttonLogout;
    private Button editButton;
    private LinearLayout buttonBack;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private TextView ETNama;
    private EditText ETAlamat, ETNoTelp, ETemail;



    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_editprofile);

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");


        ETNama = findViewById(R.id.ETnamaprof);
        ETemail = findViewById(R.id.ETemailprof);
        ETAlamat = findViewById(R.id.ETalamatprof);
        ETNoTelp = findViewById(R.id.ETnotelpprof);
        editButton = findViewById(R.id.edit_profile_btn);
        radioGroup = findViewById(R.id.radioGroup);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);

        buttonLogout = findViewById(R.id.btnLogout);
        buttonBack = findViewById(R.id.btnBack);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonProfile.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        editButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startEditProfile(ETemail.getText().toString(), ETNoTelp.getText().toString(), ETAlamat.getText().toString());
            }
        });

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminEditProfileActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminEditProfileActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminEditProfileActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(), "Logged Out", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(AdminEditProfileActivity.this, LandingPilihActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminEditProfileActivity.this.finish();
            }
        });

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
        databaseReference.child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild(username)) {
                    ETNama.setText(username);
                    String email = snapshot.child(username).child("email").getValue(String.class);
                    ETemail.setText(email);
                    String noTelp = snapshot.child(username).child("noTelp").getValue(String.class);
                    ETNoTelp.setText(noTelp);
                    String gender = snapshot.child(username).child("gender").getValue(String.class);
                    if(gender.equals("Male")){
                        radioGroup.check(R.id.maleRadioButton);
                    }
                    else{
                        radioGroup.check(R.id.femaleRadioButton);
                    }
                    String alamat = snapshot.child(username).child("alamat").getValue(String.class);
                    ETAlamat.setText(alamat);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }

    public void startEditProfile(String email, String noTelp, String alamat){
        int selectedId = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);
        String gender = (String) radioButton.getText();
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
        databaseReference.child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild(username)) {
                    databaseReference.child("admin").child(username).child("email").setValue(email);
                    databaseReference.child("admin").child(username).child("noTelp").setValue(noTelp);
                    databaseReference.child("admin").child(username).child("gender").setValue(gender);
                    databaseReference.child("admin").child(username).child("alamat").setValue(alamat);
                    Toast.makeText(getApplicationContext(), "Data Successfully Changed.", Toast.LENGTH_SHORT).show();
                }
                else{
                    Toast.makeText(getApplicationContext(), "User not found.", Toast.LENGTH_SHORT).show();
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}