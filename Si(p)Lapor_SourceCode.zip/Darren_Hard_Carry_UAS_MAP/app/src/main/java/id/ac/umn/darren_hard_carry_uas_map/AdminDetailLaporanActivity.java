package id.ac.umn.darren_hard_carry_uas_map;

import android.app.DatePickerDialog;
import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.DatePicker;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;
import com.squareup.picasso.Picasso;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.Locale;

public class AdminDetailLaporanActivity extends AppCompatActivity{

    private ImageView buttonHome, buttonAdd, buttonProfile, detailImage;
    private TextView pelapor, detailTanggal, namaMasalah, detailEstimasi;
    private LinearLayout buttonBack;
    private Button buttonEstimasi;
    private Spinner dropdownStatus;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_detaillaporan);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonEstimasi = findViewById(R.id.btnEstimasi);
        buttonBack = findViewById(R.id.btnBack);
        dropdownStatus = findViewById(R.id.dropdownStatus);
        detailImage = findViewById(R.id.detail_image);
        pelapor = findViewById(R.id.detailNamaPelapor);
        detailTanggal = findViewById(R.id.detailTanggal);
        namaMasalah = findViewById(R.id.masalah);
        detailEstimasi = findViewById(R.id.detailEstimasi);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonHome.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(this,
                R.array.list_status, android.R.layout.simple_spinner_item);
        adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
        dropdownStatus.setAdapter(adapter);

        Bundle bundle = getIntent().getExtras();
        String tanggalPelaporan = bundle.getString("tanggalLaporan");
        String namaPelapor = bundle.getString("namaPelapor");
        String statusLaporan = bundle.getString("status");
        String linkGambar = bundle.getString("linkGambar");
        String masalah = bundle.getString("namaMasalah");

        pelapor.setText(namaPelapor);
        detailTanggal.setText(tanggalPelaporan);
        namaMasalah.setText(masalah);
        Picasso.get().load(linkGambar).into(detailImage);

        detailImage.setScaleType( ImageView.ScaleType.CENTER_CROP );
        detailImage.setRotation(90);

        final Calendar newCalendar = Calendar.getInstance();
        final DatePickerDialog  datePicker = new DatePickerDialog(this, new DatePickerDialog.OnDateSetListener() {
            public void onDateSet(DatePicker view, int year, int monthOfYear, int dayOfMonth) {
                Calendar newDate = Calendar.getInstance();
                newDate.set(year, monthOfYear, dayOfMonth);
                SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
                detailEstimasi.setText(df.format(newDate.getTime()));
            }

        }, newCalendar.get(Calendar.YEAR), newCalendar.get(Calendar.MONTH), newCalendar.get(Calendar.DAY_OF_MONTH));

        buttonEstimasi.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                datePicker.show();
            }
        });

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminDetailLaporanActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminDetailLaporanActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminDetailLaporanActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminDetailLaporanActivity.this.finish();
            }
        });
    }
}