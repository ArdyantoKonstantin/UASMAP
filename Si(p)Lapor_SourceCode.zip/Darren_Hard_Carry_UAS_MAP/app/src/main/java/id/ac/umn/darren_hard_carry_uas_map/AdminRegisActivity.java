package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminRegisActivity extends AppCompatActivity {

    private EditText username, email, password, confPassword, noTelpRegis, alamatAdmin;
    private Button buttonRegis;
    private LinearLayout buttonBack;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_register);

        username = findViewById(R.id.nama);
        email = findViewById(R.id.email);
        password = findViewById(R.id.password);
        confPassword = findViewById(R.id.re_password);
        alamatAdmin = findViewById(R.id.alamatAdmin);
        noTelpRegis = findViewById(R.id.noTelpRegis);
        radioGroup = findViewById(R.id.radioGroup);

        buttonRegis = findViewById(R.id.btnRegis);
        buttonBack = findViewById(R.id.btnBack);

        buttonRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startRegister(username.getText().toString(), email.getText().toString(), noTelpRegis.getText().toString(),password.getText().toString(), confPassword.getText().toString(), alamatAdmin.getText().toString());
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminRegisActivity.this.finish();
            }
        });
    }

    private void startRegister(String username, String email, String noTelpRegis,String password, String confPassword, String alamat){
        int selectedId = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);
        String gender = (String) radioButton.getText();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
        if(TextUtils.isEmpty(username)){
            Toast.makeText(getApplicationContext(), "Please insert your username.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(email)){
            Toast.makeText(getApplicationContext(), "Please insert your email.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(noTelpRegis)){
            Toast.makeText(getApplicationContext(), "Please insert your no telp.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(password)){
            Toast.makeText(getApplicationContext(), "Please insert your password.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(confPassword)){
            Toast.makeText(getApplicationContext(), "Please rewrite your password correctly.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty((alamat))){
            Toast.makeText(getApplicationContext(), "Please insert your address.", Toast.LENGTH_SHORT).show();
        }
        else{
            if(confPassword.equals(password)){
                databaseReference.child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.hasChild(username)){
                            Toast.makeText(getApplicationContext(), "Your username already exist.", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            databaseReference.child("admin").child(username).child("email").setValue(email);
                            databaseReference.child("admin").child(username).child("alamat").setValue(alamat);
                            databaseReference.child("admin").child(username).child("password").setValue(password);
                            databaseReference.child("admin").child(username).child("noTelp").setValue(noTelpRegis);
                            databaseReference.child("admin").child(username).child("gender").setValue(gender);
                            Toast.makeText(getApplicationContext(), "User Successfully added.", Toast.LENGTH_SHORT).show();
                            finish();
                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
            else{
                Toast.makeText(getApplicationContext(), "Please enter the same password.", Toast.LENGTH_SHORT).show();
            }
        }

    }
}