package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;
import java.util.UUID;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminGetKeyCodeActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private LinearLayout buttonBack;
    private TextView keyCode;
    private Button newCode;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_getkeycode);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonBack = findViewById(R.id.btnBack);
        keyCode = findViewById(R.id.code);
        newCode = findViewById(R.id.newCode);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonProfile.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        Bundle extras = getIntent().getExtras();
        String namaKos = extras.getString("namaKos");

        newCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String uniqueID = UUID.randomUUID().toString();
                System.out.println("Unique ID: "+ uniqueID.substring(0,7).toUpperCase());

                keyCode.setText(uniqueID.substring(0,7).toUpperCase());

                firebaseDatabase = FirebaseDatabase.getInstance();
                databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
                databaseReference.child("generateKeyCode").addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        databaseReference.child("generateKeyCode").child("keyCode").setValue(uniqueID.substring(0,7).toUpperCase());
                        databaseReference.child("generateKeyCode").child("lokasiKos").setValue(namaKos);
                        Toast.makeText(getApplicationContext(), "Keycode succesfully generated.", Toast.LENGTH_SHORT).show();
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
        });

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminGetKeyCodeActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminGetKeyCodeActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminGetKeyCodeActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminGetKeyCodeActivity.this.finish();
            }
        });
    }
}