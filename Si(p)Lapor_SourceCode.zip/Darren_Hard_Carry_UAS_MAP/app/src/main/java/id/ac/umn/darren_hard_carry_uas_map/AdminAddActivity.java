package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ArrayAdapter;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;


import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.Query;
import com.google.firebase.database.ValueEventListener;

import java.util.ArrayList;
import java.util.List;

public class AdminAddActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private Button buttonListAnakKos, buttonTambahAnakKos, buttonGenerateCode;
    private Spinner dropdownListKos;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    private List<String> list;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_add);

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");

        list = new ArrayList<>();

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonGenerateCode = findViewById(R.id.btnGenerateCode);

        dropdownListKos = findViewById(R.id.dropdownListKos);
        buttonListAnakKos = findViewById(R.id.btnListAnakKos);
        buttonTambahAnakKos = findViewById(R.id.btnTambahAnakKos);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonAdd.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");

        databaseReference.child("ListKos").orderByChild("pemilikKos").equalTo(username).addValueEventListener(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                for (DataSnapshot ds : snapshot.getChildren()){
                    String kos  = ds.child("namaKos").getValue(String.class);
                    list.add(kos);
                }

                ArrayAdapter<String> adapter = new ArrayAdapter<String>(AdminAddActivity.this, android.R.layout.simple_spinner_dropdown_item, list);
                adapter.setDropDownViewResource(android.R.layout.simple_spinner_dropdown_item);
                dropdownListKos.setAdapter(adapter);

            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {
                Toast.makeText(getApplicationContext(), "Database Error.", Toast.LENGTH_SHORT).show();
            }
        });


        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminAddActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminAddActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonListAnakKos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminAddActivity.this, AdminListAnakKosActivity.class);
                intent.putExtra("namaKos", dropdownListKos.getSelectedItem().toString());
                startActivity(intent);
            }
        });

        buttonTambahAnakKos.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminAddActivity.this, AdminTambahKosActivity.class);
                startActivity(intent);
            }
        });

        buttonGenerateCode.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String namaKos = dropdownListKos.getSelectedItem().toString();
                Intent intent = new Intent (AdminAddActivity.this, AdminGetKeyCodeActivity.class);
                intent.putExtra("namaKos", namaKos);
                startActivity(intent);
            }
        });
    }
}