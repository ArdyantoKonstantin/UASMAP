package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.content.SharedPreferences;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminLoginActivity extends AppCompatActivity {
    private EditText username, password;
    private Button buttonLogin;
    private TextView buttonRegis;
    private LinearLayout buttonBack;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;
    public boolean isLogin = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_login);

        username = findViewById(R.id.email);
        password = findViewById(R.id.password);

        buttonLogin = findViewById(R.id.btnLogin);
        buttonRegis = findViewById(R.id.btnRegis);
        buttonBack = findViewById(R.id.btnBack);



        buttonLogin.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startlogin(username.getText().toString(), password.getText().toString());

            }
        });

        buttonRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminLoginActivity.this, AdminRegisActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminLoginActivity.this.finish();
            }
        });
    }
    private void startlogin(String username, String password){

        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");

        if (TextUtils.isEmpty(username)) {
            Toast.makeText(getApplicationContext(), "Please insert your username.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(password)){
            Toast.makeText(getApplicationContext(), "Please insert your password.", Toast.LENGTH_SHORT).show();
        }else{
            databaseReference.child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.hasChild(username)){
                        String getPassword = snapshot.child(username).child("password").getValue(String.class);
                        if(getPassword.equals(password)){

                            SharedPreferences sharedPreferences = getSharedPreferences("MySharedPref",MODE_PRIVATE);
                            sharedPreferences.edit().putBoolean("Islogin", isLogin).commit();
                            sharedPreferences.edit().putString("username", username).commit();
                            sharedPreferences.edit().putString("position", "Admin").commit();
                            Intent intent = new Intent (AdminLoginActivity.this, AdminHomeActivity.class);
                            startActivity(intent);
                        }
                        else{
                            Toast.makeText(getApplicationContext(), "Incorrect Username or Password", Toast.LENGTH_LONG).show();
                        }
                    }
                    else{
                        Toast.makeText(getApplicationContext(), "User not found, please register", Toast.LENGTH_LONG).show();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

    }


}