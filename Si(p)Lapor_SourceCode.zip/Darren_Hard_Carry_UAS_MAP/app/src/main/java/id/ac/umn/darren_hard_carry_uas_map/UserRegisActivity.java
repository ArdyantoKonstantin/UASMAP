package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class UserRegisActivity extends AppCompatActivity {

    private EditText namaUser, emailUser, passUser, conf_passUser, codeUser;

    private Button buttonRegis;
    private LinearLayout buttonBack;
    private RadioGroup radioGroup;
    private RadioButton radioButton;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_register);

        namaUser = findViewById(R.id.namaUser);
        emailUser = findViewById(R.id.emailUser);
        passUser = findViewById(R.id.passwordUser);
        conf_passUser = findViewById(R.id.re_passwordUser);
        codeUser = findViewById(R.id.uniqueUser);
        radioGroup = findViewById(R.id.radioGroup);

        buttonRegis = findViewById(R.id.btnRegis);
        buttonBack = findViewById(R.id.btnBack);

        buttonRegis.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startUserRegis(namaUser.getText().toString(), emailUser.getText().toString(), passUser.getText().toString(), conf_passUser.getText().toString(), codeUser.getText().toString());
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserRegisActivity.this.finish();
            }
        });
    }

    private void startUserRegis(String namaUser, String emailUser, String pass, String conf_passUser, String code_User) {
        int selectedId = radioGroup.getCheckedRadioButtonId();
        radioButton = (RadioButton) findViewById(selectedId);
        String gender = (String) radioButton.getText();
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");

        if(TextUtils.isEmpty(namaUser)){
            Toast.makeText(getApplicationContext(), "Please insert your username.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(emailUser)){
            Toast.makeText(getApplicationContext(), "Please insert your email.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(pass)){
            Toast.makeText(getApplicationContext(), "Please insert your password.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(code_User)){
            Toast.makeText(getApplicationContext(), "Please insert your uniqueCode.", Toast.LENGTH_SHORT).show();
        }
        else {
            if(pass.equals(conf_passUser)){

                databaseReference.addListenerForSingleValueEvent(new ValueEventListener() {
                    @Override
                    public void onDataChange(@NonNull DataSnapshot snapshot) {
                        if(snapshot.child("users").hasChild(namaUser)){
                            Toast.makeText(getApplicationContext(), "Your username already exist.", Toast.LENGTH_SHORT).show();
                        }
                        else{
                            String UID = snapshot.child("generateKeyCode").child("keyCode").getValue(String.class);
                            if(UID.equals(code_User)){
                                String lokasiKos = snapshot.child("generateKeyCode").child("lokasiKos").getValue(String.class);
                                databaseReference.child("users").child(namaUser).child("email").setValue(emailUser);
                                databaseReference.child("users").child(namaUser).child("password").setValue(pass);
                                databaseReference.child("users").child(namaUser).child("lokasiKos").setValue(lokasiKos);
                                databaseReference.child("admin").child(namaUser).child("gender").setValue(gender);
                                Intent intent = new Intent (UserRegisActivity.this, UserLoginActivity.class);
                                startActivity(intent);
                                Toast.makeText(getApplicationContext(), "User succesfully registered.", Toast.LENGTH_SHORT).show();
                            }
                            else{
                                Toast.makeText(getApplicationContext(), "Your username already exist.", Toast.LENGTH_SHORT).show();
                            }

                        }
                    }

                    @Override
                    public void onCancelled(@NonNull DatabaseError error) {

                    }
                });
            }
            else{
                Toast.makeText(getApplicationContext(), "Please insert write your password correctly.", Toast.LENGTH_SHORT).show();
            }
        }
    }
}