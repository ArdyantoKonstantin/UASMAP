package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminProfileActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile, buttonLogout;
    private Button buttonGenerateCode;
    private LinearLayout buttonEdit;
    private TextView namaProfile, alamatProfile, noTelpProfile, genderProfile, emailProfile;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_profile);

        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonLogout = findViewById(R.id.btnLogout);
        namaProfile = findViewById(R.id.name_text);
        alamatProfile = findViewById(R.id.address_text);
        noTelpProfile = findViewById(R.id.phone_number);
        genderProfile = findViewById(R.id.gender_text);
        emailProfile = findViewById(R.id.email_text);

        buttonEdit = findViewById(R.id.btnEdit);
        //buttonGenerateCode = findViewById(R.id.btnGenerateCode);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonProfile.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminProfileActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminProfileActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonEdit.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminProfileActivity.this, AdminEditProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonLogout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Toast.makeText(getBaseContext(), "Logged Out", Toast.LENGTH_LONG).show();
                Intent intent = new Intent(AdminProfileActivity.this, LandingPilihActivity.class);
                startActivity(intent);
            }
        });
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
        databaseReference.child("admin").addListenerForSingleValueEvent(new ValueEventListener() {
            @Override
            public void onDataChange(@NonNull DataSnapshot snapshot) {
                if (snapshot.hasChild(username)) {
                    namaProfile.setText(username);
                    String email = snapshot.child(username).child("email").getValue(String.class);
                    emailProfile.setText(email);
                    String noTelp = snapshot.child(username).child("noTelp").getValue(String.class);
                    noTelpProfile.setText(noTelp);
                    String gender = snapshot.child(username).child("gender").getValue(String.class);
                    genderProfile.setText(gender);
                    String alamat = snapshot.child(username).child("alamat").getValue(String.class);
                    alamatProfile.setText(alamat);
                }
            }

            @Override
            public void onCancelled(@NonNull DatabaseError error) {

            }
        });
    }
}