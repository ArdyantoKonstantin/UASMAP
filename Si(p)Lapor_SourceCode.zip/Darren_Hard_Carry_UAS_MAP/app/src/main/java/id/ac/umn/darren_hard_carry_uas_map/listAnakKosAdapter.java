package id.ac.umn.darren_hard_carry_uas_map;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import com.firebase.ui.database.FirebaseRecyclerAdapter;
import com.firebase.ui.database.FirebaseRecyclerOptions;

public class listAnakKosAdapter extends FirebaseRecyclerAdapter<listAnakKos, listAnakKosAdapter.listAnakKosViewHolder>{

    public listAnakKosAdapter(@NonNull FirebaseRecyclerOptions<listAnakKos> options) {
        super(options);
    }

    @Override
    protected void onBindViewHolder(@NonNull listAnakKosAdapter.listAnakKosViewHolder holder, int position, @NonNull listAnakKos model) {
        holder.nama.setText(model.getNama());
    }

    @NonNull
    @Override
    public listAnakKosViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        View view = LayoutInflater.from(parent.getContext()).inflate(R.layout.list_anakkos, parent, false);
        return new listAnakKosAdapter.listAnakKosViewHolder(view);
    }

    public class listAnakKosViewHolder extends RecyclerView.ViewHolder {
        TextView nama;
        public listAnakKosViewHolder(@NonNull View itemView) {
            super(itemView);
            nama = itemView.findViewById(R.id.nama);
        }
    }
}
