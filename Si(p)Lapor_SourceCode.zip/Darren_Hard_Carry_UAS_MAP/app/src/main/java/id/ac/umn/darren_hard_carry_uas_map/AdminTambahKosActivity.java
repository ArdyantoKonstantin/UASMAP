package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.text.TextUtils;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RadioButton;
import android.widget.RadioGroup;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;

public class AdminTambahKosActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private Button buttonSave;
    private LinearLayout buttonBack;

    private EditText namaKos, alamatKos, notelp;

    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_admin_tambahkos);

        namaKos = findViewById(R.id.nama_kos);
        alamatKos = findViewById(R.id.alamat_kos);
        notelp = findViewById(R.id.noTelp_PemilikKos);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonBack = findViewById(R.id.btnBack);
        buttonSave = findViewById(R.id.save_Kos);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonAdd.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);


        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminTambahKosActivity.this, AdminHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminTambahKosActivity.this, AdminAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (AdminTambahKosActivity.this, AdminProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                AdminTambahKosActivity.this.finish();
            }
        });

        buttonSave.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
                String username = sh.getString("username", "");
                startRegisterKos(username, namaKos.getText().toString(), notelp.getText().toString(), alamatKos.getText().toString());
            }
        });
    }

    public void startRegisterKos(String pemilikKos, String namaKos, String NoTelp, String alamat){
        //int selectedId = radioGroup.getCheckedRadioButtonId();
        //radioButton = (RadioButton) findViewById(selectedId);
        //String gender = (String) radioButton.getText();
        if(TextUtils.isEmpty(pemilikKos)){
            Toast.makeText(getApplicationContext(), "Please insert your username.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(namaKos)){
            Toast.makeText(getApplicationContext(), "Please insert your Nama Kos.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(NoTelp)){
            Toast.makeText(getApplicationContext(), "Please insert your No telp.", Toast.LENGTH_SHORT).show();
        }
        else if(TextUtils.isEmpty(alamat)){
            Toast.makeText(getApplicationContext(), "Please insert your alamat.", Toast.LENGTH_SHORT).show();
        }
        else{
            firebaseDatabase = FirebaseDatabase.getInstance();
            databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
            databaseReference.child("ListKos").addListenerForSingleValueEvent(new ValueEventListener() {
                @Override
                public void onDataChange(@NonNull DataSnapshot snapshot) {
                    if(snapshot.hasChild(namaKos)){
                        Toast.makeText(getApplicationContext(), "Your Nama Kos already exist.", Toast.LENGTH_SHORT).show();
                    }
                    else{
                        databaseReference.child("ListKos").child(namaKos).child("alamat").setValue(alamat);
                        //databaseReference.child("ListKos").child(namaKos).child("email").setValue(Email);
                        //databaseReference.child("ListKos").child(namaKos).child("gender").setValue(gender);
                        databaseReference.child("ListKos").child(namaKos).child("namaKos").setValue(namaKos);
                        databaseReference.child("ListKos").child(namaKos).child("pemilikKos").setValue(pemilikKos);
                        databaseReference.child("ListKos").child(namaKos).child("telp").setValue(NoTelp);
                        Toast.makeText(getApplicationContext(), "Kos Successfully added.", Toast.LENGTH_SHORT).show();
                        finish();
                    }
                }

                @Override
                public void onCancelled(@NonNull DatabaseError error) {

                }
            });
        }

    }

}