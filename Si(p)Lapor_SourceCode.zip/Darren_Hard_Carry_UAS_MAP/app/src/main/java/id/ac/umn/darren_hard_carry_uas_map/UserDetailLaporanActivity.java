package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.os.Bundle;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.ActionBar;
import androidx.appcompat.app.AppCompatActivity;

import com.squareup.picasso.Picasso;

public class UserDetailLaporanActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile, selectedImage;
    private TextView pelapor, detailTanggal, namaMasalah, status;
    private LinearLayout buttonBack;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_detaillaporan);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        buttonBack = findViewById(R.id.btnBack);
        pelapor = findViewById(R.id.namaPelapor);
        detailTanggal = findViewById(R.id.tanggalLaporan);
        namaMasalah = findViewById(R.id.namaMasalah);
        selectedImage = findViewById(R.id.imageDetail);
        status = findViewById(R.id.status);

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonHome.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);

//        ActionBar actionBar = getSupportActionBar();
//        actionBar.setDisplayHomeAsUpEnabled(true);

        Bundle bundle = getIntent().getExtras();
        String tanggalPelaporan = bundle.getString("tanggalLaporan");
        String namaPelapor = bundle.getString("namaPelapor");
        String statusLaporan = bundle.getString("status");
        String linkGambar = bundle.getString("linkGambar");
        String masalah = bundle.getString("namaMasalah");

        pelapor.setText(namaPelapor);
        detailTanggal.setText(tanggalPelaporan);
        namaMasalah.setText(masalah);
        status.setText(statusLaporan);
        Picasso.get().load(linkGambar).into(selectedImage);

        selectedImage.setScaleType( ImageView.ScaleType.CENTER_CROP );
        selectedImage.setRotation(90);

        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserDetailLaporanActivity.this, UserHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonAdd.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserDetailLaporanActivity.this, UserAddActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserDetailLaporanActivity.this, UserProfileActivity.class);
                startActivity(intent);
            }
        });

        buttonBack.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                UserDetailLaporanActivity.this.finish();
            }
        });
    }

//    @Override
//    public boolean onCreateOptionsMenu(Menu menu) {
//        getMenuInflater().inflate(R.menu.menu_main, menu);
//        return true;
//    }
//
//    @Override
//    public boolean onOptionsItemSelected(@NonNull MenuItem item) {
//        switch (item.getItemId()) {
//            case android.R.id.home:
//                this.finish();
//                return true;
//            case R.id.action_logout:
//                Toast.makeText(this, "Logged Out", Toast.LENGTH_LONG).show();
//                Intent intent = new Intent(UserDetailLaporanActivity.this, LandingPilihActivity.class);
//                startActivity(intent);
//                return(true);
//        }
//        return super.onOptionsItemSelected(item);
//    }
}