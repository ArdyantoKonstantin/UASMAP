package id.ac.umn.darren_hard_carry_uas_map;

import android.Manifest;
import android.app.Activity;
import android.content.ContentResolver;
import android.content.Context;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Resources;
import android.graphics.PorterDuff;
import android.net.Uri;
import android.os.Bundle;
import android.os.Environment;
import android.provider.MediaStore;
import android.util.Log;
import android.view.Menu;
import android.view.MenuItem;
import android.view.View;
import android.webkit.MimeTypeMap;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.core.app.ActivityCompat;
import androidx.core.content.ContextCompat;
import androidx.core.content.FileProvider;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.database.DataSnapshot;
import com.google.firebase.database.DatabaseError;
import com.google.firebase.database.DatabaseReference;
import com.google.firebase.database.FirebaseDatabase;
import com.google.firebase.database.ValueEventListener;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;
import com.squareup.picasso.Picasso;
import java.util.Calendar;
import java.util.Date;

import java.io.File;
import java.io.IOException;
import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class UserAddActivity extends AppCompatActivity {

    private ImageView buttonHome, buttonAdd, buttonProfile;
    private Button openCameraButton, uploadBtn;
    private String URIpath;
//    private EditText detailKeluhan;
    private Spinner listMasalah;
    public Uri contentUri;
    FirebaseStorage storage;
    StorageReference storageReference;
    String currentPhotoPath;
    ImageView selectedImage;
    public static final int CAMERA_PERM_CODE = 101;
    public static final int CAMERA_REQUEST_CODE = 102;
    public static final int GALLERY_REQUEST_CODE = 105;
    FirebaseDatabase firebaseDatabase;
    DatabaseReference databaseReference;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_user_add);

        buttonHome = findViewById(R.id.btnHome);
        buttonAdd = findViewById(R.id.btnAdd);
        buttonProfile = findViewById(R.id.btnProfile);
        openCameraButton = findViewById(R.id.openCameraBtn);
        selectedImage = findViewById(R.id.selectedImage);
        uploadBtn = findViewById(R.id.uploadBtn);
        storage = FirebaseStorage.getInstance();
        listMasalah = findViewById(R.id.spinner_Masalah);
//        detailKeluhan = findViewById(R.id.keluhan_pelapor);
        storageReference = storage.getReferenceFromUrl("gs://mapproject-eac5c.appspot.com");

        Resources res = getBaseContext().getResources();
        final int newColor = res.getColor(R.color.defaultBlue);
        buttonAdd.setColorFilter(newColor, PorterDuff.Mode.SRC_ATOP);
        buttonHome.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserAddActivity.this, UserHomeActivity.class);
                startActivity(intent);
            }
        });

        buttonProfile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (UserAddActivity.this, UserProfileActivity.class);
                startActivity(intent);
            }
        });

        uploadBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                uploadImageToFirebase(URIpath, contentUri, listMasalah.getSelectedItem().toString());
            }
        });

        openCameraButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                askCameraPermissions();
            }
        });
    }

    private void askCameraPermissions() {
        if(ContextCompat.checkSelfPermission(this, Manifest.permission.CAMERA) != PackageManager.PERMISSION_GRANTED){
            ActivityCompat.requestPermissions(this, new String[]{Manifest.permission.CAMERA}, CAMERA_PERM_CODE);
        }
        else{
            dispatchTakePictureIntent();
        }
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, @NonNull String[] permissions, @NonNull int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if(requestCode == CAMERA_PERM_CODE){
            if(grantResults.length > 0 && grantResults[0] == PackageManager.PERMISSION_GRANTED){
                dispatchTakePictureIntent();
            }
            else{
                Toast.makeText(this, "Camera is needed", Toast.LENGTH_SHORT).show();
            }
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if(requestCode == CAMERA_REQUEST_CODE){
            if(resultCode == Activity.RESULT_OK){
                File f = new File(currentPhotoPath);
                Intent mediaScanIntent = new Intent(Intent.ACTION_MEDIA_SCANNER_SCAN_FILE);
                contentUri = Uri.fromFile(f);
                mediaScanIntent.setData(contentUri);
                this.sendBroadcast(mediaScanIntent);
                selectedImage.setImageURI(contentUri);
                selectedImage.setScaleType( ImageView.ScaleType.CENTER_CROP );
                URIpath = f.getName();
            }
        }

        if(requestCode == GALLERY_REQUEST_CODE){
            if(resultCode == Activity.RESULT_OK){
                contentUri = data.getData();
                String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
                String imageFileName = "JPEG_" + timeStamp + "."+ getFileExt(contentUri);
                selectedImage.setImageURI(contentUri);
                selectedImage.setScaleType( ImageView.ScaleType.CENTER_CROP );
                URIpath = imageFileName;
            }
        }
    }

    private void uploadImageToFirebase(String name, Uri contentUri, String detailKeluhan) {
        SharedPreferences sh = getSharedPreferences("MySharedPref", Context.MODE_PRIVATE);
        String username = sh.getString("username", "");
        String namaKos = sh.getString("namaKos", "");
        firebaseDatabase = FirebaseDatabase.getInstance();
        databaseReference = firebaseDatabase.getReferenceFromUrl("https://mapproject-eac5c-default-rtdb.firebaseio.com/");
        StorageReference image = storageReference.child("pictures/" + name);
        if(contentUri == null){
            Toast.makeText(UserAddActivity.this, "Picture must be uploaded", Toast.LENGTH_SHORT).show();
        }
        else{
            image.putFile(contentUri).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {
                    image.getDownloadUrl().addOnSuccessListener(new OnSuccessListener<Uri>() {
                        @Override
                        public void onSuccess(Uri uri) {
                            //Picasso.get().load(uri).into(selectedImage);
                            Date currentTime = Calendar.getInstance().getTime();
                            SimpleDateFormat df = new SimpleDateFormat("dd-MMM-yyyy", Locale.getDefault());
                            String formattedDate = df.format(currentTime);
                            databaseReference.child("ListMasalah").addListenerForSingleValueEvent(new ValueEventListener() {
                                @Override
                                public void onDataChange(@NonNull DataSnapshot snapshot) {
                                    if(snapshot.hasChild(detailKeluhan)){
                                        String getKos = snapshot.child(detailKeluhan).child("lokasi").getValue(String.class);
                                        if(getKos.equals(namaKos)){
                                            int UpVote = snapshot.child(detailKeluhan).child("UpVote").getValue(int.class) + 1;
                                            String pelapor = snapshot.child(detailKeluhan).child("Pelapor").getValue(String.class);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("Pelapor").setValue(username.concat(", "+pelapor));
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("UpVote").setValue(UpVote);
                                        }
                                        else{
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("NamaMasalah").setValue(detailKeluhan);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("Pelapor").setValue(username);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("lokasi").setValue(namaKos);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("linkGambar").setValue(uri.toString());
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("UpVote").setValue(1);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("TanggalPelaporan").setValue(formattedDate);
                                            databaseReference.child("ListMasalah").child(detailKeluhan).child("status").setValue("Waiting For Confirmation");
                                        }

                                    }
                                    else{
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("NamaMasalah").setValue(detailKeluhan);
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("Pelapor").setValue(username);
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("lokasi").setValue(namaKos);
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("linkGambar").setValue(uri.toString());
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("UpVote").setValue(1);
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("TanggalPelaporan").setValue(formattedDate);
                                        databaseReference.child("ListMasalah").child(detailKeluhan).child("status").setValue("Waiting For Confirmation");
                                    }

                                }
                                @Override
                                public void onCancelled(@NonNull DatabaseError error) {

                                }
                            });
                        }
                    });
                    Toast.makeText(UserAddActivity.this, "Upload success", Toast.LENGTH_SHORT).show();
                    Intent intent = new Intent (UserAddActivity.this, UserHomeActivity.class);
                    startActivity(intent);
                }
            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {
                    Toast.makeText(UserAddActivity.this, "Upload failed", Toast.LENGTH_SHORT).show();
                }
            });
        }

    }

    private String getFileExt(Uri contentUri) {
        ContentResolver c = getContentResolver();
        MimeTypeMap mime = MimeTypeMap.getSingleton();
        return mime.getExtensionFromMimeType(c.getType(contentUri));
    }

    private File createImageFile() throws IOException {
        String timeStamp = new SimpleDateFormat("yyyyMMdd_HHmmss").format(new Date());
        String imageFileName = "JPEG_" + timeStamp + "_";
        File storageDir = Environment.getExternalStoragePublicDirectory(Environment.DIRECTORY_PICTURES);
        File image = File.createTempFile(
                imageFileName,  /* prefix */
                ".jpg",         /* suffix */
                storageDir      /* directory */
        );
        currentPhotoPath = image.getAbsolutePath();
        return image;
    }

    private void dispatchTakePictureIntent() {
        Intent takePictureIntent = new Intent(MediaStore.ACTION_IMAGE_CAPTURE);
        File photoFile = null;
        try {
            photoFile = createImageFile();
        } catch (IOException ex) {

        }
        Uri photoURI = FileProvider.getUriForFile(this,
                "id.ac.umn.android.fileprovider",
                photoFile);
        takePictureIntent.putExtra(MediaStore.EXTRA_OUTPUT, photoURI);
        startActivityForResult(takePictureIntent, CAMERA_REQUEST_CODE);
    }

}