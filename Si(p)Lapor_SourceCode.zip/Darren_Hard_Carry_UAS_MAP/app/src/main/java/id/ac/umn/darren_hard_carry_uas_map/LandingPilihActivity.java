package id.ac.umn.darren_hard_carry_uas_map;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import androidx.appcompat.app.AppCompatActivity;
import androidx.appcompat.app.AppCompatDelegate;

public class LandingPilihActivity extends AppCompatActivity {

    private Button userButton, adminButton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landingpilih);

        userButton = findViewById(R.id.btnUser);
        adminButton = findViewById(R.id.btnAdmin);

        userButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (LandingPilihActivity.this, UserLoginActivity.class);
                startActivity(intent);
            }
        });
        adminButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent (LandingPilihActivity.this, AdminLoginActivity.class);
                startActivity(intent);
            }
        });
    }
}
