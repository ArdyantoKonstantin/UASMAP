package id.ac.umn.darren_hard_carry_uas_map;

public class ListMasalah {
    private String NamaMasalah, Pelapor, lokasi, linkGambar, status, TanggalPelaporan;
    private int UpVote;

    public int getUpVote() {
        return UpVote;
    }

    public void setUpVote(int upVote) {
        UpVote = upVote;
    }

    public ListMasalah(){}

    public String getNamaMasalah() {
        return NamaMasalah;
    }

    public void setNamaMasalah(String namaMasalah) {
        this.NamaMasalah = namaMasalah;
    }

    public String getPelapor() {
        return Pelapor;
    }

    public void setPelapor(String namaPelapor) {
        this.Pelapor = namaPelapor;
    }

    public String getLokasi() {
        return lokasi;
    }

    public void setLokasi(String lokasi) {
        this.lokasi = lokasi;
    }

    public String getLinkGambar() {
        return linkGambar;
    }

    public void setLinkGambar(String linkGambar) {
        this.linkGambar = linkGambar;
    }

    public String getStatus() {
        return status;
    }

    public void setStatus(String status) {
        this.status = status;
    }

    public String getTanggalPelaporan() {
        return TanggalPelaporan;
    }

    public void setTanggalPelaporan(String tanggalPelaporan) {
        TanggalPelaporan = tanggalPelaporan;
    }
}
